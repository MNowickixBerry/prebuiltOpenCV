import os

BINARIES_PATHS = [
    os.path.join('/usr/local', 'lib')
] + BINARIES_PATHS

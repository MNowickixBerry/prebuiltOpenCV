PYTHON_EXTENSIONS_PATHS = [
    os.path.join('/usr/lib/python3/dist-packages/cv2', 'python-3.6')
] + PYTHON_EXTENSIONS_PATHS
